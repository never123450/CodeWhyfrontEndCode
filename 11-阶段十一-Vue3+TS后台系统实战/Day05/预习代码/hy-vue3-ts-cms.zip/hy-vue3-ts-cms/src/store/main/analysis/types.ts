export interface IAnalysis {
  topPanelDatas: any[]
  categoryGoodsCount: any[]
  categoryGoodsSale: any[]
  categoryGoodsFavor: any[]
  goodsSaleTop10: any[]
  goodsAddressSale: any[]
}
