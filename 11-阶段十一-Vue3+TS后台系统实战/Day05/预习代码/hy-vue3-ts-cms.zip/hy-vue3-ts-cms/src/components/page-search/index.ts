import PageSearch from './src/page-search.vue'

export default PageSearch
