export interface IDepartment {
  id: number
  name: string
  parentId: any
  createAt: string
  updateAt: string
  leader: string
}
