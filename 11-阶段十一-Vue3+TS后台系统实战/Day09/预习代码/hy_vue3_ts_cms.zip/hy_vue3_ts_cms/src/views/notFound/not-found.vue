<template>
  <div class="not-found">not-found</div>
</template>

<script setup lang="ts" name="not-found"></script>

<style scoped lang="less">
.not-found {
}
</style>
