<template>
  <div class="menu">
    <h2>menu</h2>
  </div>
</template>

<script setup lang="ts" name="menu"></script>

<style scoped>
.menu{
}
</style>
