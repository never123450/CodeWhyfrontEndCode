<template>
  <div class="department">
    <h2>department</h2>
  </div>
</template>

<script setup lang="ts" name="department"></script>

<style scoped>
.department{
}
</style>
