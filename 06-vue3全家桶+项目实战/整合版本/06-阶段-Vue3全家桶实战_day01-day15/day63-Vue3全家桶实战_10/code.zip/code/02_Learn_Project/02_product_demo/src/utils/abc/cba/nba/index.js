// 配置别名
import { sum } from "utils/math"


console.log(sum(20, 30))

