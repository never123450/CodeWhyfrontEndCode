<template>
  <div>AppContent</div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
</style>


