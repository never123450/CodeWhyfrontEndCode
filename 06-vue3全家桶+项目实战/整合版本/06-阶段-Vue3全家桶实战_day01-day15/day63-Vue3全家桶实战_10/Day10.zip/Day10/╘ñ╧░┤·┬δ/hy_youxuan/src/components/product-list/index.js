import ProductList from './src/product-list.vue'
import ProductListItem from './src/product-list-item.vue'

export {
  ProductList,
  ProductListItem
}