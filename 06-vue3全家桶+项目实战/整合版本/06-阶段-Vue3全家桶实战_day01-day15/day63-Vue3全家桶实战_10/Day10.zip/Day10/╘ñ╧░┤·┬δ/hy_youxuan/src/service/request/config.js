// export const BASE_URL = "http://localhost:8010/youxuan/api"
export const BASE_URL = "/youxuan/api"
export const TIMEOUT = 10000