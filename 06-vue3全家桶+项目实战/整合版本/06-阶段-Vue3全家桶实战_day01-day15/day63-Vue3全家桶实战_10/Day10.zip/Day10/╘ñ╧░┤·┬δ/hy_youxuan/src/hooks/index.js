import useNinePage from './useNinePage'
export {
    useNinePage
}