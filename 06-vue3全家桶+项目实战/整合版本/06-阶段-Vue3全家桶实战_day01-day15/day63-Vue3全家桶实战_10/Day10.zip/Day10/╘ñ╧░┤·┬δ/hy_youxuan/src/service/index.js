import HYRequest from './request/request'
import { BASE_URL, TIMEOUT } from './request/config'

export default new HYRequest(BASE_URL, TIMEOUT)
