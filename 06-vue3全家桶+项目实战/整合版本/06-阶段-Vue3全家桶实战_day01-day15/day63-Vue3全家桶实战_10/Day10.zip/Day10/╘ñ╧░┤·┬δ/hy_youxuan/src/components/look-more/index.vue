<template>
  <div class="look-more">
    查看更多
  </div>
</template>

<script>
  export default {
    name: "look-more"
  }
</script>
<script setup>

</script>

<style lang="less" scoped>
  .look-more {
    cursor: pointer;
    margin: 20px auto;
    width: 250px;
    font-size: 24px;
    font-weight: 500;
    line-height: 70px;
    text-align: center;
    color: #43240c;
    background-color: #fee44e;
    border-radius: 35px;
  }
</style>