import NavHeader from './src/nav-header.vue'

export default NavHeader
