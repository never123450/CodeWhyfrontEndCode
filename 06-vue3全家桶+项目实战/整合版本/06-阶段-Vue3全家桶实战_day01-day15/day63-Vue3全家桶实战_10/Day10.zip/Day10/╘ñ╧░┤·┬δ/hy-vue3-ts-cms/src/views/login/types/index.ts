export interface Account {
  name: string
  password: string
}
