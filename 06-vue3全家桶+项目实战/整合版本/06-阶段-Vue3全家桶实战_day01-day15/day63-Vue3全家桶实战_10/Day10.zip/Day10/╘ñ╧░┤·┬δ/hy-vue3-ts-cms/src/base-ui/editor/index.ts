import HyEditor from './src/index.vue'

export default HyEditor
