export interface ILoginState {
  token: string
  userInfo: any
  userMenus: any
  permissions: string[]
}
