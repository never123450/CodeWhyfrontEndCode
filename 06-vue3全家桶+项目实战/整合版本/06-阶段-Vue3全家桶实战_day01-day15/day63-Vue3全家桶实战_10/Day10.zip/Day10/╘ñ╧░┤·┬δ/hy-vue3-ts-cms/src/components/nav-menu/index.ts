import NavMenu from './src/nav-menu.vue'

export default NavMenu
