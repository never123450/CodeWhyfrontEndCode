import HyTable from './src/table.vue'

export default HyTable
