<script setup>

</script>


<template>
  <van-tabbar route active-color="#ff9645">
    <van-tabbar-item to="/home" icon="wap-home-o">首页</van-tabbar-item>
    <van-tabbar-item to="/favor" icon="like-o">收藏</van-tabbar-item>
    <van-tabbar-item to="/order" icon="orders-o">订单</van-tabbar-item>
    <van-tabbar-item to="/message" icon="chat-o">消息</van-tabbar-item>
  </van-tabbar>
</template>


<style scoped>

</style>