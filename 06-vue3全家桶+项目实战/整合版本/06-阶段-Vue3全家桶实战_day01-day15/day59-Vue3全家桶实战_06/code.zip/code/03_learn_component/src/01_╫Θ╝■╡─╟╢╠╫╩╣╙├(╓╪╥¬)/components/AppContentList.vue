<template>
  <ul>
    <li>商品列表1</li>
    <li>商品列表2</li>
    <li>商品列表3</li>
    <li>商品列表4</li>
  </ul>
</template>

<script>
  export default {

  }
</script>

<style scoped>
</style>

