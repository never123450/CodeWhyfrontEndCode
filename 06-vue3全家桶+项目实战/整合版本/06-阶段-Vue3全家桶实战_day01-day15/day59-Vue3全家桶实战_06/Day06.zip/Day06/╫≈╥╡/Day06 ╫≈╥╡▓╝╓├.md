# Day06 作业布置

## 一. 完成上课所有的代码练习







## 二. ref和reactive有什么区别？开发中如何选择？







## 三. 整理Composition API常见的几个函数用法

* ref
* reactive
* computed
* 生命周期
* watch
* watchEffect





## 四. watch和watchEffect有什么区别？

* 懒执行副作用（第一次不会直接执行）；

* 更具体的说明当哪些状态发生变化时，触发侦听器的执行；

* 访问侦听状态变化前后的值；





## 五. 说说script setup语法糖的常见用法







## 六. 完成阶段案例实战练习













































