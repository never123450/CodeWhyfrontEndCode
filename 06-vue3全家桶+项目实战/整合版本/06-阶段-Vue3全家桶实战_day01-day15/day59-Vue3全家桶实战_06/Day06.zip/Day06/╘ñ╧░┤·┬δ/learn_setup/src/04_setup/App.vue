<script setup>
  import { ref } from 'vue';
  import ShowInfo from './ShowInfo.vue'

  const name = ref("why")
  const age = ref(18)

  function changeAge(payload) {
    age.value = payload
  }

  const showInfoRef = ref(null)
  function callShowInfo() {
    showInfoRef.value.foo()
  }

</script>


<template>
  <show-info ref="showInfoRef" :name="name" :age="age" @change-age="changeAge"></show-info>
  <button @click="callShowInfo">调用showInfo的foo</button>
  <br><br><br><br><br>
  <br><br><br><br><br>
  <br><br><br><br><br>
  <br><br><br><br><br>
  <br><br><br><br><br>
  <br><br><br><br><br>
</template>


<style scoped>

</style>