<script>
  import { inject, ref } from 'vue'

  export default {
    props: {
      info: {
        type: Object,
        default: () => ({})
      }
    },
    inject: ["name"],
    setup(props) {
      const message = ref("Hello World")

      const changeName = () => {
        props.info.name = "kobe"
      }

      // const name = inject("name")
      const account = inject("account")

      return {
        message,
        changeName,
        // name,
        account
      }
    }
  }
</script>


<template>
  <h2>info: {{ info }}</h2>
  <button @click="changeName">修改name</button>

  <hr>
  <h2>name: {{ name.value }}</h2>
  <h2>account: {{ account }}</h2>
</template>


<style scoped>

</style>