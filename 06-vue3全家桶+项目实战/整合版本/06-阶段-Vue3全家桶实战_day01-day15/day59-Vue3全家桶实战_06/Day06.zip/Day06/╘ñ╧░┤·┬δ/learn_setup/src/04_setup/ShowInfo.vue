<script setup>
  import useTitle from './hooks/useTitle'
  import useScroll from './hooks/useScroll'

  const props = defineProps({
    name: {
      type: String,
      default: ""
    },
    age: {
      type: Number,
      default: 0
    }
  })

  const emit = defineEmits(["changeAge"])
  function changeAge() {
    emit("changeAge", 200)
  }

  const title = useTitle("我是标题")
  const { scrollX, scrollY } = useScroll()

  function foo() {
    console.log("foo function")
    title.value = "哈哈哈"
  }

  defineExpose({
    foo
  })

</script>


<template>
  <h2>ShowInfo: {{ name }}-{{ age }}</h2>
  <button @click="changeAge">修改age</button>
  <h2>X:{{scrollX}}-Y:{{scrollY}}</h2>
</template>


<style lang="scss" scoped>

</style>