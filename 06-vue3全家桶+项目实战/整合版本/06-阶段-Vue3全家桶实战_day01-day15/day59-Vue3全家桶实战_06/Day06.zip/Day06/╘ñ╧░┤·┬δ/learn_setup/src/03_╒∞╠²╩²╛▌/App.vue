<script>
  import { reactive, ref, watch } from 'vue'

  export default {
    setup(props) {
      const info = reactive({
        name: "why",
        age: 18,
        friend: {
          name: "kobe"
        }
      })

      watch(info, (newValue, oldValue) => {
        console.log(newValue, oldValue)
      }, {
        immediate: true,
        deep: true
      })

      watch(() => ({...info}), (newValue, oldValue) => {
        console.log(newValue, oldValue)
      }, {
        // immediate: true,
        deep: true
      })

      const changeData = () => {
        info.friend.name = "aaa"
      }

      return {
        // message,
        changeData
      }
    }
  }
</script>


<template>
  <h2>message: {{ message }}</h2>
  <button @click="changeData">修改数据</button>
</template>


<style scoped>

</style>