<script>
  import { reactive, ref } from 'vue'

  export default {
    setup() {
      const counter = ref(0)
      const rCounter = reactive({
        counter
      })
      const info = {
        counter
      }

      return {
        counter,
        rCounter,
        info
      }
    }

  }
</script>


<template>
  <h2>当前计数: {{counter}}</h2>
  <h2>当前计数: {{rCounter.counter}}</h2>
  <h2>当前计数: {{info.counter}}</h2>
  <button @click="info.counter.value++">+1</button>
  <button @click="counter++">+1</button>
</template>


<style scoped>

</style>