import { createApp } from 'vue'
// import App from './02_常见函数/App.vue'
// import App from './03_侦听数据/App.vue'
import App from './04_setup/App.vue'

const app = createApp(App)

app.mount('#app')
