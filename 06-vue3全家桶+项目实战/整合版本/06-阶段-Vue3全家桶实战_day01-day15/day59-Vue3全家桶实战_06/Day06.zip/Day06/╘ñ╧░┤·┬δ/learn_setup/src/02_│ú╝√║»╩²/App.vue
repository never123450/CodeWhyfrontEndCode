<script>
  import { ref, reactive, readonly, toRefs, isProxy, isReactive, inject, provide } from 'vue'
  import ShowInfo from './ShowInfo.vue'

  export default {
    components: {
      ShowInfo
    },
    setup() {
      // 1.ref定义的数据
      const name = ref("why")
      console.log(name.value)

      // 2.一次性定义多个响应式数据
      const account = reactive({
        username: "",
        password: ""
      })

      // 3.信息
      const info = reactive({
        name: "why",
        age: 18,
        height: 1.88
      })

      const { age, height } = toRefs(info)
      console.log(age)

      const readonlyName = readonly(name)
      console.log(readonlyName.value)
      name.value = "111"
      console.log(readonlyName.value)

      const changeAge = () => {
        info.age = 100
        name.value = "hhahahah"
      }

      const rInfo = readonly({
        name: "why"
      })

      // console.log(isProxy(info))
      // console.log(isReactive(info))
      // console.log(isProxy(name.value))
      // console.log(isReactive(name.value))
      console.log(isProxy(rInfo))
      console.log(isReactive(rInfo))
      console.log(isReactive(readonly(info)))

      provide("name", name)
      provide("account", account)


      return {
        account,
        info: readonly(info),
        age,
        changeAge
      }
    }
  }
</script>


<template>
  <h2>Home</h2>
  <form>
    用户:<input type="text" v-model="account.username">
    密码:<input type="text" v-model="account.password">
  </form>
  <h2>info: {{ info }}</h2>
  <show-info :info="info"></show-info>

  <h2>age: {{ age }}</h2>
  <button @click="changeAge">修改age</button>
</template>


<style scoped>

</style>