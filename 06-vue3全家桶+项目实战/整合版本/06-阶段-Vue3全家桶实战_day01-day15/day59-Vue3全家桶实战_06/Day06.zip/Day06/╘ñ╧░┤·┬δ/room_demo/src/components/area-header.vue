<script setup>
  defineProps({
    title: {
      type: String,
      default: "区域标题"
    },
    desc: {
      type: String,
      default: "品质房源，低至 5 折"
    }
  })
</script>

<template>
  <div class="area-header">
    <h3 class="title">{{ title }}</h3>
    <p class="desc">{{ desc }}</p>
  </div>
</template>

<style lang="less" scoped>
  .area-header {
    height: 84px;

    .title {
      font-size: 22px;
    }

    .desc {
      margin-top: 12px;
      font-size: 16px;
    }
  }
</style>