<script setup>
import AreaHeader from './components/area-header.vue'
import RoomItem from './components/room-item.vue'
import highScore from './data/high_score.json'

</script>

<template>
  <div class="app">
    <div class="section">
      <area-header :title="highScore.title" :desc="highScore.desc"></area-header>
      <div class="room-list">
        <template v-for="item in highScore.list" :key="item.id">
          <room-item :item-data="item"></room-item>
        </template>
      </div>
    </div>
  </div>
</template>

<style lang="less">
  .section {
    width: 1032px;
    margin: 0 auto;

    .room-list {
      display: flex;
      flex-wrap: wrap;
      margin: 30px -8px 0;
    }
  }

</style>
