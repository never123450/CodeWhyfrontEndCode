<template>
  <div class="home">
    <h2>Counter0: {{ counterStore.counter }}</h2>
    <h2>Counter1: {{ counter }}</h2>
    <h2>Counter2: {{ counter2 }}</h2>
    <h2>Counter3: {{ counter3 }}</h2>
    <h2>CounterState: {{ counterStore.name }}</h2>
  </div>
</template>

<script setup>
  import { toRefs } from 'vue'
  import { storeToRefs } from 'pinia'
  import { useCounter } from '@/store/counter'

  const counterStore = useCounter()

  counterStore.counter++
  counterStore.name = "coderwhy"

  const { counter } = counterStore // 不是响应式的
  const { counter: counter2 } = toRefs(counterStore) // 是响应式的
  const { counter: counter3 } = storeToRefs(counterStore) // 是响应式的

  setTimeout(() => {
    const counterStore = useCounter()

    // counterStore.$patch({
    //   counter: 100,
    //   name: "kobe"
    // })

    counterStore.$state = { 
      counter: 1, 
      name: "why" 
    }

    // counterStore.$reset()
  }, 2000)
</script>

<style scoped>

</style>