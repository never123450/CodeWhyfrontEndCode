import { defineStore } from 'pinia'

export const useUser = defineStore("user", {
  state: () => ({
    nickname: "coderwhy"
  })
})
