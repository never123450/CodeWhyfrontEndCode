<template>
  <h2>About</h2>
  <!-- <input type="text" ref="inputRef"> -->
  <input type="text" v-focus>
  <button v-if="counter < 5" @click="counter++" v-why.aaaa.bbbb="'哈哈哈'">当前计数: {{ counter }}</button>
  <h2 v-format-time="'YYYY/MM/DD'">1658506496412</h2>
</template>

<script>
  // export default {
  //   directives: {
  //     focus: {
  //       mounted(el) {
  //         el.focus()
  //       }
  //     }
  //   }
  // }
</script>

<script setup>

  import { ref, onMounted } from 'vue'

  // const vFocus = {
  //   mounted(el) {
  //     el.focus()
  //   }
  // }

  const vWhy = {
    created(el, bindings, newVNode, oldVNode) {
      console.log("created")
      console.log(el, bindings, newVNode, oldVNode)
    },
    beforeMount() {
      console.log("beforeMount")
    },
    mounted() {
      console.log("mounted")
    },
    beforeUpdate() {
      console.log("beforeUpdate")
    },
    updated(el, bindings, newVNode, oldVNode) {
      console.log("updated")
      console.log(el, bindings, newVNode, oldVNode)
    },
    beforeUnmount() {
      console.log("beforeUnmount")
    },
    unmounted() {
      console.log("unmounted")
    }
  }

  // const inputRef = ref()
  // onMounted(() => {
  //   inputRef.value.focus()
  // })

  const counter = ref(0)

</script>

<style scoped>

</style>