import { createApp } from 'vue'
import App from './App.vue'
import pinia from './store'
import formatTime from './directives/format-time'

const app = createApp(App)
app.directive("focus", {
  mounted(el) {
    el.focus()
  }
})
// app.directive("format-time", {

// })
app.use(formatTime)
app.use(pinia).mount('#app')

console.log(new Date().getTime())
