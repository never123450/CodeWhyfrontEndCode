import dayjs from 'dayjs'

export default function(app) {
  console.log("----")
  app.directive("format-time", {
    mounted(el, bindings) {
      let formatString = "YYYY-MM-DD HH:mm:ss"
      if (bindings.value) {
        formatString = bindings.value
      }
      console.log(formatString)

      const textContent = el.textContent
      const timestamp = parseInt(textContent)

      el.textContent = dayjs(timestamp).format(formatString)
    }
  })
}