<template>
  <div class="app">
    <!-- <home/> -->
    <!-- <teleport to='#why'>
      <about/>
    </teleport> -->

    <suspense>
      <template #default>
        <async-home />
      </template>
      <template #fallback>
        <h2>Loading</h2>
      </template>
    </suspense>
  </div>
</template>

<script setup>

// import Home from './views/Home.vue'
import { defineAsyncComponent } from 'vue';
import About from './views/About.vue'

const AsyncHome = defineAsyncComponent(() => import("./views/Home.vue"))

</script>

<style>
</style>
