import { defineStore } from 'pinia'

import { useUser } from './user'

export const useCounter = defineStore("counter", {
  state: () => ({
    counter: 100,
    firstname: "kobe",
    lastname: "bryant",
    age: 18
  }),
  getters: {
    doubleCounter: (state) => state.counter * 2,
    doublePlusOne: function(state) {
      return this.doubleCounter + 1
    },
    fullname: (state) => state.firstname + state.lastname,
    message: function(state) {
      const userStore = useUser()
      return this.fullname + ":" + userStore.nickname
    }
  },
  actions: {
    increment() {
      this.counter++
    },
    randomCounter() {
      this.counter = Math.random()
    },
    async fetchHomeDataAction() {
      const res = await fetch("http://123.207.32.32:8000/home/multidata")
      const data = await res.json()
      console.log("data:", data)
      return data
    }
  }
})
