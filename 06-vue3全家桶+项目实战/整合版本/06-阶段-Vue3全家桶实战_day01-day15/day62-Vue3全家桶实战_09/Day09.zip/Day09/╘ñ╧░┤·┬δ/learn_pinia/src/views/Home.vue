<template>
  <div class="home">
    <h2>Counter: {{ counterStore.doubleCounter }}</h2>
    <h2>Counter: {{ counterStore.doublePlusOne }}</h2>
    <h2>Message: {{ counterStore.message }}</h2>

    <h2>User: {{ getUserById(111) }}</h2>
    <h2>User: {{ getUserById(112) }}</h2>

    <button @click="increment">+1</button>
    <button @click="randomClick">随机数字</button>
  </div>
</template>

<script setup>
  import { useCounter } from "@/store/counter"
  import { useMain } from "@/store/main"

  const counterStore = useCounter()

  counterStore.$onAction(({name, store, args, after, onError}) => {
    console.log("开始订阅action:", name, store, args)

    after(result => {
      console.log("action执行完成:", result)
    })

    onError(error => {
      console.log("action发生错误:", error)
    })
  })

  counterStore.fetchHomeDataAction().then(res => {
    console.log(res)
  })

  console.log(counterStore.doubleCounter)
  console.log(counterStore.fullname)


  const mainStore = useMain()
  const getUserById = mainStore.getUserById

  counterStore.$subscribe((mutation, state) => {
    console.log(mutation, state)
  })

  function increment() {
    counterStore.increment(111)
  }

  function randomClick() {
    counterStore.randomCounter()
  }

</script>

<style scoped>

</style>