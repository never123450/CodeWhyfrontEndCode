import { defineStore } from 'pinia'

export const useMain = defineStore("main", {
  state: () => ({
    users: [
      { id: 111, name: "why", age: 18 },
      { id: 112, name: "kobe", age: 20 },
      { id: 113, name: "james", age: 25 },
    ]
  }),
  getters: {
    getUserById(state) {
      return userId => {
        return state.users.find(item => item.id === userId)
      }
    }
  }
})
