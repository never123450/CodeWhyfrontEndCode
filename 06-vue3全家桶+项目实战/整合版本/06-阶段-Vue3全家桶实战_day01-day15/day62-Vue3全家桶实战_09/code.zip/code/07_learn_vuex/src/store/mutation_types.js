export const CHANGE_INFO = "changeInfo"
