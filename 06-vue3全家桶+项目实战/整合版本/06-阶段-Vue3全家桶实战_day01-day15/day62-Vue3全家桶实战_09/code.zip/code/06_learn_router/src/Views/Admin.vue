<template>
  <div>
    <h2>Admin</h2>
    <p>哈哈哈哈哈哈哈</p>
    <p>哈哈哈哈哈哈哈</p>
    <p>哈哈哈哈哈哈哈</p>
    <p>哈哈哈哈哈哈哈</p>
    <p>哈哈哈哈哈哈哈</p>
    <p>哈哈哈哈哈哈哈</p>
  </div>
</template>

<script setup>

</script>

<style scoped>
</style>

