<template>
  <div class="hello-world">
    <h2>Hello World</h2>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>
