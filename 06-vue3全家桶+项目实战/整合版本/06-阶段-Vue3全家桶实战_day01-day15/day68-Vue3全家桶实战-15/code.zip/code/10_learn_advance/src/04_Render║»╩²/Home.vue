<template>
  <div class="home">
    <h2>home Page</h2>
  </div>
</template>

<script setup>

</script>

<style lang="less" scoped>

</style>
