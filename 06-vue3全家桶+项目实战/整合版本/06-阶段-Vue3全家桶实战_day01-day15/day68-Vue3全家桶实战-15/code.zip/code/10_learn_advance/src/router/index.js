import { createRouter } from 'vue-router'

const router = createRouter({
  // history:
})

export default router

