<template>
  <div class="about">
    <h2>home page</h2>
  </div>
</template>

<script setup>
</script>

<style scoped>
.about {
  text-align: center;
}
</style>
