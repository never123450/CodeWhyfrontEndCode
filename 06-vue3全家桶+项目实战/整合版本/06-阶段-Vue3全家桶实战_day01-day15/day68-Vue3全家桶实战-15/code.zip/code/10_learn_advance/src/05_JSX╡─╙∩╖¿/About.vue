<template>
  <div class="about">
    <h2>about page</h2>
  </div>
</template>

<script setup>

</script>

<style lang="less" scoped>

</style>
