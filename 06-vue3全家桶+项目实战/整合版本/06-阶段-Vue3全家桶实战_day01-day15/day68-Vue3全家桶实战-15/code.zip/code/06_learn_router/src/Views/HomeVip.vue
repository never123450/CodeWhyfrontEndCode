<template>
  <div>
    <h2>HomeVip</h2>
    <h2></h2>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
</style>

