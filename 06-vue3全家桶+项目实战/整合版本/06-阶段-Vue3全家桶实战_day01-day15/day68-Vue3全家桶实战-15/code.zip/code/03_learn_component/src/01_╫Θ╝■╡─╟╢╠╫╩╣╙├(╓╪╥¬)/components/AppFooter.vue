<template>
  <div class="footer">
    <div>物流配送</div>
    <div>版权声明</div>
    <div>免责声明</div>
    <div>注册地址: 广州市天河区</div>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
  .footer {
    background-color: green;
  }
</style>

