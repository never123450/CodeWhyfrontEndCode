let num = 100
foo()

function foo() {
  console.log(num * 2)
  console.log(num * num)
}

num = 200
foo()

