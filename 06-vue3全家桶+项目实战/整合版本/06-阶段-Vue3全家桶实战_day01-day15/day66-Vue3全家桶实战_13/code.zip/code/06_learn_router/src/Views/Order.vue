<template>
  <div class="order">
    <h2>订单页面</h2>
    <ul>
      <li>订单1</li>
      <li>订单2</li>
      <li>订单3</li>
      <li>订单4</li>
      <li>订单5</li>
    </ul>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
</style>

