<template>
  <div class="message">
    <h2>message</h2>
  </div>
</template>

<script setup>

</script>

<style lang="less" scoped>

</style>
