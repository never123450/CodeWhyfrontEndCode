<template>
  <div class="guide-login">guide-login</div>
</template>

<script setup></script>

<style scoped>
.guide-login {
  position: sticky;
  top: 0;
  height: 58px;
  margin-bottom: 20px;
  /* margin-left: 20px;
  margin-right: 20px; */
  background-color: pink;
  /* transition: all 1 linear; */
}
</style>
