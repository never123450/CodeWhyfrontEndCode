import { createStore } from 'vuex'
import moduleA from './moduleA'

const store = createStore({
  state() {
    return {
      name: "why",
      age: 18,
      height: 1.88,
      count: 100
    }
  },
  mutations: {
    changeName(state) {
      state.name = "coderwhy"
    }
  },
  getters: {
    myname(state) {
      return state.name
    }
  },
  modules: {
    a: moduleA
  }
})

export default store

