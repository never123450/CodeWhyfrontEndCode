<template>
  <h2>Category: {{ name }}-{{ age }}</h2>
  <h2>MyName: {{ myname }}</h2>
  <button @click="changeName">修改</button>
</template>

<script setup>
import { toRefs } from 'vue';
import { useStore } from 'vuex'

const store = useStore()

const { name, age } = toRefs(store.state)
const { myname } = toRefs(store.getters)

function changeName() {
  store.commit({
    type: "changeName"
  })
}

</script>

<style scoped>

</style>