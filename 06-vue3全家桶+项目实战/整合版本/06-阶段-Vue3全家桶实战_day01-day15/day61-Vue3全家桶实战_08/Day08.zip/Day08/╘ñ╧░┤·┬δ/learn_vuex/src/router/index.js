import { createRouter, createWebHashHistory, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      redirect: "/home"
    },
    {
      path: "/home",
      name: "home",
      component: () => import(/* webpackChunkName: 'home-chunk' */"../views/Home.vue"),
      meta: {
        name: "why",
        age: 18
      }
    },
    {
      path: "/about",
      name: "about",
      component: () => import(/* webpackChunkName: 'about-chunk' */"../views/About.vue")
    },
    {
      path: "/category",
      name: "category",
      component: () => import(/* webpackChunkName: 'about-chunk' */"../views/Category.vue")
    }
  ]
})

export default router
