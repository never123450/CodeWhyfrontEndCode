<template>
  <div class="home">
    <!-- 1.获取共享的数据 -->
    <h2>store: {{ $store.state.name }}</h2>
    <h2>computed: {{ name }}-{{ age }}</h2>
    <h2>computed: {{ counter }}</h2>
    <h2>computed: {{ height }}</h2>
  </div>
</template>

<script>
  import { mapState } from 'vuex'

  export default {
    computed: {
      ...mapState(["name", "age"]),
      ...mapState({
        counter: state => state.count * 2
      })
    },
    created() {
      console.log(this.$store.state.name)
    }
  }
</script>

<script setup>

import { computed } from 'vue'
import { useStore, mapState } from 'vuex'

const store = useStore()
console.log(store.state.name)

const name = computed(() => store.state.name + "111")
const stateMapFns = mapState(["name", "age"])
const age = computed(stateMapFns["age"].bind({ $store: store }))
const stateMapFns2 = mapState({
  height: state => state.height * 2
})
const height = computed(stateMapFns2["height"].bind({ $store: store }))

</script>

<style scoped>

</style>