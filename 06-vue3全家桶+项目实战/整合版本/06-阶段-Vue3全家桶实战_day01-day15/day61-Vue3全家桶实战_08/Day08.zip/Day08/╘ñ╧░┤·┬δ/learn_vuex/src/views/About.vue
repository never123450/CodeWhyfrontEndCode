<template>
  <h2>About:{{ name }}</h2>
  <h2>message:{{ message }}</h2>
  <h2>message:{{ $store.state.a.message }}</h2>
  <h2>fullname: {{ $store.getters["a/fullname"] }}</h2>
</template>

<script setup>
import { useStore } from 'vuex'
import useState from "@/hooks/useState"
import { computed } from 'vue';

const store = useStore()

const { name } = useState({
  name: state => state.name
})

const message = store.state.a.message

store.commit("a/changeMessage", "呵呵呵")

</script>

<style scoped>

</style>