<template>
  <div class="app">
    <router-link to="/home" replace>首页</router-link>
    <router-link to="/about" replace>关于</router-link>
    <router-link to="/category" replace>关于</router-link>
    <router-view/>
  </div>
</template>

<script setup>

</script>

<style lang="less">

</style>
