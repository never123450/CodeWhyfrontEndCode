import { mapState, useStore } from 'vuex'
import { computed } from 'vue'

export default function useState(mapper) {
  const store = useStore()
  const stateFns = mapState(mapper)

  const state = {}
  Object.keys(stateFns).forEach(key => {
    state[key] = computed(stateFns[key].bind({ $store: store }))
  })

  return state
}