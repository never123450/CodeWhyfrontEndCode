const moduleA = {
  namespaced: true,
  state() {
    return {
      message: "哈哈哈",
      firstname: "kobe",
      lastname: "bryant"
    }
  },
  getters: {
    fullname(state, getters, rootState, rootGetters) {
      return state.firstname + " " + state.lastname + getters.info + rootState.name + rootGetters.myname
    },
    info(state) {
      return state.message
    }
  },
  mutations: {
    changeMessage(state, payload) {
      state.message = payload
    }
  },
  actions: {
    getServerNameAction({ commit, dispatch, state, rootState }) {
      
    }
  }
}

export default moduleA
