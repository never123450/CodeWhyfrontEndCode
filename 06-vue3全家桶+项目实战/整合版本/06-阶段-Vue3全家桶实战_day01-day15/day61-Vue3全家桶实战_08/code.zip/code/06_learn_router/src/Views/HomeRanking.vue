<template>
  <div class="home-ranking">
    <h2>各种榜单</h2>
    <ul>
      <li>热歌榜</li>
      <li>新歌榜</li>
      <li>原创榜</li>
      <li>歌手榜单</li>
    </ul>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
</style>

