<template>
  <div class="app-header">
    <h1 class="title">
      我是大标题
    </h1>
    <h2 class="subtitle">
      我是小标题
    </h2>
  </div>
</template>


<script>
  export default {
  }
</script>


<style scoped>
</style>