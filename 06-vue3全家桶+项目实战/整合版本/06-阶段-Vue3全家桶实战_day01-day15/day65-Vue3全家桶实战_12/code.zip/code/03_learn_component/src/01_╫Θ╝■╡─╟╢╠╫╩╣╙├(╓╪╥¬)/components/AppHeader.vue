<template>
  <div class="header">
    <div class="top">top banner</div>
    <input type="text">
    <div class="nav">nav</div>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
  .header {
    background-color: orange;
  }
</style>

