<template>
  <div class="app">
    <router-link to="/home" replace>首页</router-link>
    <router-link to="/about" replace>关于</router-link>
    <router-link to="/user/123" replace>用户</router-link>
    <router-link to="/category" replace>分类</router-link>
    <router-link to="/abc/cba/nba">abc</router-link>
    <router-view/>

    <button @click="pushToProfile">跳转到Profile</button>

    <div class="room-area">
      <area-header :title="highScore.title" :subtitle="highScore.subtitle"></area-header>
      <div class="room-list">
        <template v-for="item in highScore.list" :key="item.id">
          <room-item :item-data="item"></room-item>
        </template>
      </div>
    </div>

  </div>
</template>

<script setup>
  import { useRouter } from 'vue-router';
  import AreaHeader from './components/area-header.vue'
  import RoomItem from './components/room-item.vue'
  import highScore from './data/high_score.json'

  const router = useRouter()

  function pushToProfile() {
    router.push({
      path: "/profile",
      query: { name: "why", age: 18 }
    })
  }

</script>

<style lang="less">
  .router-link-active {
    color: red;
  }

  .room-area {
    width: 1032px;
    margin: 0 auto;

    .room-list {
      display: flex;
      flex-wrap: wrap;
      margin: 30px -8px 0;
    }
  }
</style>
