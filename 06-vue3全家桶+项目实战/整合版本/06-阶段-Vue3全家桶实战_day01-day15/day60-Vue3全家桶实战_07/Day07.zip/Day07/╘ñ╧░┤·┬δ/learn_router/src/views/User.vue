<template>
  <h2>用户id: {{ $route.params.id }}</h2>
</template>

<script setup>

import { useRoute } from 'vue-router'

const route = useRoute()
console.log(route.params.id)

</script>

<style scoped>

</style>