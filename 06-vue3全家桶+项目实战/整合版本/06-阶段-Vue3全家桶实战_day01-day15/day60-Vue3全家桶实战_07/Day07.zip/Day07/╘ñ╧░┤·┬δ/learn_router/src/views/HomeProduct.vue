<template>
  <h2>商品列表</h2>
  <ul>
    <li>商品列表</li>
    <li>商品列表</li>
    <li>商品列表</li>
    <li>商品列表</li>
    <li>商品列表</li>
  </ul>
</template>

<script setup>

</script>

<style scoped>

</style>