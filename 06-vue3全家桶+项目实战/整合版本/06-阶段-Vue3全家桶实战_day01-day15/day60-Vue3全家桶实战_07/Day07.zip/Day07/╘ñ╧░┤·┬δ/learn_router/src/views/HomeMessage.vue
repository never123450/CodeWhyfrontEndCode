<template>
  <h2>消息列表</h2>
  <ul>
    <li>消息列表1</li>
    <li>消息列表2</li>
    <li>消息列表3</li>
    <li>消息列表4</li>
    <li>消息列表5</li>
  </ul>
</template>

<script setup>

</script>

<style scoped>

</style>