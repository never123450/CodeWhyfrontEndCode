<template>
  <h2>NotFound: {{ $route.params.pathMatch }}</h2>
</template>

<script setup>

</script>

<style scoped>

</style>