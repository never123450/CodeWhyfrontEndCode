<template>
  <h2>HomeMoment</h2>
</template>

<script setup>

</script>

<style scoped>

</style>