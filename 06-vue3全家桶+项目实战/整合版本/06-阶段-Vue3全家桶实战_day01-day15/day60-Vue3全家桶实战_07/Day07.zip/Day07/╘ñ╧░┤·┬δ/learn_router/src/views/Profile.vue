<template>
  <h2>Profile: {{ $route.query }}</h2>
  <button @click="backClick">返回</button>
</template>

<script setup>
  import { useRouter } from 'vue-router'

  const router = useRouter()

  function backClick() {
    router.go(-1)
  }
</script>

<style scoped>

</style>