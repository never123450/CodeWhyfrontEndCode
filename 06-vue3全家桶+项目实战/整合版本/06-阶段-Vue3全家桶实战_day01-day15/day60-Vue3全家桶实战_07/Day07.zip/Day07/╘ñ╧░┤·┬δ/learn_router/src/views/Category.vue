<template>
  <h2>Category</h2>
</template>

<script setup>

</script>

<style scoped>

</style>