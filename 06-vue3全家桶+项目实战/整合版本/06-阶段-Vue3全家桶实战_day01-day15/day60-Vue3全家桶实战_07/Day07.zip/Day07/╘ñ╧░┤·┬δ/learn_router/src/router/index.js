import { createRouter, createWebHashHistory, createWebHistory } from 'vue-router'

// import Home from '../views/Home.vue'
// import About from '../views/About.vue'

const router = createRouter({
  // history: createWebHashHistory(),
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      redirect: "/home"
    },
    {
      path: "/home",
      name: "home",
      component: () => import(/* webpackChunkName: 'home-chunk' */"../views/Home.vue"),
      meta: {
        name: "why",
        age: 18
      },
      children: [
        {
          path: "",
          name: "home",
          redirect: "/home/product"
        },
        {
          path: "product",
          component: () => import("../views/HomeProduct.vue")
        },
        {
          path: "message",
          component: () => import("../views/HomeMessage.vue")
        }
      ]
    },
    {
      path: "/about",
      name: "about",
      component: () => import(/* webpackChunkName: 'about-chunk' */"../views/About.vue")
    },
    {
      path: "/user/:id",
      component: () => import("../views/User.vue")
    },
    {
      path: "/profile",
      component: () => import("../views/Profile.vue")
    },
    {
      path: "/:pathMatch(.*)*",
      component: () => import("../views/NotFound.vue")
    }
  ]
})

// 动态添加路由
router.addRoute({
  path: "/category",
  component: () => import("../views/Category.vue")
})

router.addRoute("home", {
  path: "moment",
  component: () => import ("../views/HomeMoment.vue")
})

export default router
