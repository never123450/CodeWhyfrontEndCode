<template>
  <h2>Home</h2>
  <router-link to="/home/product">商品</router-link>
  <router-link to="/home/message">消息</router-link>
  <router-link to="/home/moment">动态</router-link>
  <router-view></router-view>
</template>

<script setup>

</script>

<style scoped>

</style>