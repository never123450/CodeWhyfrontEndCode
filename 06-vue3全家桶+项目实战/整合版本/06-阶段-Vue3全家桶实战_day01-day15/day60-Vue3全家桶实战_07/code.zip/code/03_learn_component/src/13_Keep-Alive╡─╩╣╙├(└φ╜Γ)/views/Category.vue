<template>
  <div>
    <h2>Category组件</h2>
  </div>
</template>

<script>
  export default {
    unmounted() {
      console.log("category unmounted")
    }
  }
</script>

<style scoped>
</style>

