import { createApp } from 'vue'
// import App from './02_Setup定义数据/App.vue'
// import App from './02_Setup定义数据/App2.vue'
// import App from './03_setup其他函数/App.vue'
// import App from './04_Setup中toRefs/App.vue'
// import App from './05_Setup中computed/App.vue'
// import App from './06_Setup中ref引入元素/App.vue'
// import App from './07_Setup生命周期函数/App.vue'
// import App from './08_Setup-Provide-Inject/App.vue'
// import App from './09_Setup-侦听数据变化/App.vue'
import App from './10_Setup-Hooks练习/App.vue'
// import App from './11_script_setup语法/App.vue'

createApp(App).mount('#app')
