<template>
  <div class="home">
    <h2>about page</h2>
  </div>
</template>

<script setup>

</script>

<style scoped>

.home {
  text-align: center;
}

</style>
