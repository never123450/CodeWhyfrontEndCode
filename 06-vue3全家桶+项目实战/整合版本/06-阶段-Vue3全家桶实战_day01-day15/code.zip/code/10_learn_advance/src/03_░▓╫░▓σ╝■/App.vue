<template>
  <div class="app">
    <h2>app</h2>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>
