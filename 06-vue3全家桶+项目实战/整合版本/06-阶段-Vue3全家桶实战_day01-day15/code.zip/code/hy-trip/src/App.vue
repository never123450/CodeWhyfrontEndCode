<template>
  <div class="app">
    <router-view/>
    <tab-bar/>
  </div>
</template>

<script setup>

import TabBar from "@/components/tab-bar/tab-bar.vue"

</script>

<style scoped>

</style>
