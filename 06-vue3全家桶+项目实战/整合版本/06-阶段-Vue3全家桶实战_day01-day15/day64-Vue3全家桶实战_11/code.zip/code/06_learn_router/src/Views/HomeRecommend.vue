<template>
  <div class="home-recommend">
    <h2>HomeRecommend</h2>
    <ul>
      <li>推荐歌单1</li>
      <li>推荐歌单2</li>
      <li>推荐歌单3</li>
      <li>推荐歌单4</li>
    </ul>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>
</style>

