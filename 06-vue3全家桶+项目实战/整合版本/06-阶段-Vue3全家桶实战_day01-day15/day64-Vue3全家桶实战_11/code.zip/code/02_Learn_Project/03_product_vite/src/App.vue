<template>
  <div>
    <h2 class="title">My App</h2>
    <p>我是内容, 哈哈哈</p>
    <app-header></app-header>
  </div>
</template>

<script>
  import AppHeader from './components/AppHeader.vue'

  export default {
    components: {
      AppHeader
    }
  }
</script>

<style scoped>

</style>

