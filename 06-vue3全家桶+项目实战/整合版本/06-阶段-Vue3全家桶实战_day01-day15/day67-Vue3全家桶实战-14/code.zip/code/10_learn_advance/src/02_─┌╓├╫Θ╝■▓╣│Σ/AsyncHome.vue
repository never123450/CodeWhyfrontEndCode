<template>
  <div class="home">
    <h2>home</h2>
  </div>
</template>

<script setup>

</script>

<style lang="less" scoped>

</style>
