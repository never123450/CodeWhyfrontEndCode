
<script>
import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  data() {
    return {
      counter: 100
    }
  },
  render() {
    return (
      <div>
        <h2>当前计数: { this.counter }</h2>
        <button onClick={this.increment}>+1</button>
      </div>
    )
  },
  methods: {
    increment() {
      this.counter++
    }
  },
  components: {
    HelloWorld
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
